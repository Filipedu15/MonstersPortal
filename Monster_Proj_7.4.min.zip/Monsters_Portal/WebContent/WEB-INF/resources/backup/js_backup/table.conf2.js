
$(document).ready(function() {
    $('[data-toggle="tooltip"]').tooltip(); 
});

$(function() {
    $(".spinner").spinner();
});

/* TouchSpin */
$(function(){ $("input").trigger("touchspin.updatesettings",{}) });
$(function(){
	$("input[name='preco_produto']").TouchSpin({
        min: 0,
        max: 10000,
        step: 0.10,
        decimals: 2,
        boostat: 5,
        maxboostedstep: 100,
        prefix: 'R$',
		verticalbuttons: true,
		verticalupclass: 'glyphicon glyphicon-plus',
		verticaldownclass: 'glyphicon glyphicon-minus'
	});
});
$(function(){
	$("input[name='desconto_produto']").TouchSpin({
        min: 0,
        postfix: '%',
		verticalbuttons: true
	});
});
/*$(function(){
	$("input[name='estoque']").TouchSpin({
		verticalbuttons: true,
		verticalupclass: 'glyphicon glyphicon-plus',
		verticaldownclass: 'glyphicon glyphicon-minus'
	});
});
$(function(){
	$("input[name='estoque_min']").TouchSpin({
		verticalbuttons: true,
		verticalupclass: 'glyphicon glyphicon-plus',
		verticaldownclass: 'glyphicon glyphicon-minus'
	});
});*/
/*$(function(){
	$("input[name='peso_produto']").TouchSpin({
        min: 0,
        max: 1000,
        step: 0.100,
        decimals: 3,
        boostat: 5,
        maxboostedstep: 10,
        postfix: 'kg',
		verticalbuttons: true,
		verticalupclass: 'glyphicon glyphicon-plus',
		verticaldownclass: 'glyphicon glyphicon-minus'
	});
});*/
$(function(){
	$("input[name='parcelas_pedido']").TouchSpin({
        min: 1,
        max: 120,
        step: 0.10,
        boostat: 1,
        maxboostedstep: 10,
		verticalbuttons: true
	});
});
$(function(){
	$("input[name='preco_pedido']").TouchSpin({
        min: 0,
        max: 10000,
        step: 0.10,
        decimals: 2,
        boostat: 5,
        maxboostedstep: 100,
        prefix: 'R$',
		verticalbuttons: true,
		verticalupclass: 'glyphicon glyphicon-plus',
		verticaldownclass: 'glyphicon glyphicon-minus'
	});
});
$(function(){
$("input[name='peso_pedido']").TouchSpin({
    min: 0,
    max: 1000,
    step: 0.100,
    decimals: 3,
    boostat: 5,
    maxboostedstep: 10,
    postfix: 'kg',
	verticalbuttons: true,
	verticalupclass: 'glyphicon glyphicon-plus',
	verticaldownclass: 'glyphicon glyphicon-minus'
});
});




