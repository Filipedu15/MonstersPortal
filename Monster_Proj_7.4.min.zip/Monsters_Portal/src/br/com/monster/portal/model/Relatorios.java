package br.com.monster.portal.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "relatorios")
public class Relatorios {

	@Id
	@GeneratedValue
	private Long id_relatorios;
	
	@NotNull
	@Column(name = "rel_funcionario_id_funcionario")
	private long funcionario_id_funcionario_relatorios;
	
	@NotNull
	@Column(name = "rel_quando")
	private String quando_relatorios;
	
	@NotNull
	@Column(name = "rel_categoria_funcao")
	private String categoria_funcao_relatorios;
	
	@NotNull
	@Column(name = "rel_resultado_funcao")
	private String resultado_funcao_relatorios;
	/*
	 |--------------------------------------
	 |			Relacionamentos				
	 |--------------------------------------
	 */
	@ManyToOne
	@JoinColumn(name = "relatorios_id_relatorios", insertable=true, updatable=true)
	private Funcionario funcionario;
	/*
	|---------------------------------------
	|		Getters And Setters(GGAS)				
	|---------------------------------------
	*/
	public Long getId_relatorios() {
		return id_relatorios;
	}

	public void setId_relatorios(Long id_relatorios) {
		this.id_relatorios = id_relatorios;
	}

	public long getFuncionario_id_funcionario_relatorios() {
		return funcionario_id_funcionario_relatorios;
	}

	public void setFuncionario_id_funcionario_relatorios(long funcionario_id_funcionario_relatorios) {
		this.funcionario_id_funcionario_relatorios = funcionario_id_funcionario_relatorios;
	}

	public String getQuando_relatorios() {
		return quando_relatorios;
	}

	public void setQuando_relatorios(String quando_relatorios) {
		this.quando_relatorios = quando_relatorios;
	}

	public String getCategoria_funcao_relatorios() {
		return categoria_funcao_relatorios;
	}

	public void setCategoria_funcao_relatorios(String categoria_funcao_relatorios) {
		this.categoria_funcao_relatorios = categoria_funcao_relatorios;
	}

	public String getResultado_funcao_relatorios() {
		return resultado_funcao_relatorios;
	}

	public void setResultado_funcao_relatorios(String resultado_funcao_relatorios) {
		this.resultado_funcao_relatorios = resultado_funcao_relatorios;
	}
	
}

