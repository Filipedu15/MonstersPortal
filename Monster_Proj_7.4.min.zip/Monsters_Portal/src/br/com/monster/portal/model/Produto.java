package br.com.monster.portal.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import br.com.monster.portal.model.Avaliacao;
import br.com.monster.portal.model.Banner;
import br.com.monster.portal.model.Categoria;
import br.com.monster.portal.model.Fornecedor;
import br.com.monster.portal.model.Imagem;
import br.com.monster.portal.model.Pedido;

@Entity
@Table(name = "produto")
public class Produto {

	@Id
	@GeneratedValue
	private long id_produto;
	
	@NotNull(message="{produto.nome.NotEmpty}")
	@Size(min=5, max=200, message = "{produto.nome.Size}")
	@Column(name = "pro_nome")
	private String nome_produto;
	
	@NotNull(message="{produto.preco.NotEmpty}")
	@Column(name = "pro_preco")
	private float preco_produto;
	
	@NotNull(message="{produto.descricao.NotEmpty}")
	@Size(min=5, max=600, message = "{produto.descricao.Size}")
	@Column(name = "pro_descricao")
	private String descricao_produto;
	
	@NotNull(message="{produto.publicado.NotEmpty}")
	@Column(name = "pro_publicado")
	private boolean publicado_produto;
	
	@NotNull(message="{produto.destaque.NotEmpty}")
	@Column(name = "pro_destaque")
	private boolean destaque_produto;
	
	@NotNull(message="{produto.desconto.NotEmpty}")
	@Column(name = "pro_desconto")
	private long desconto_produto;
	
	@NotNull(message="{produto.promocao.NotEmpty}")
	@Column(name = "pro_promocao")
	private boolean promocao_produto;
	
	@NotNull(message="{produto.peso.NotEmpty}")
	@Size(min=1, max=12, message = "{produto.peso.Size}")
	@Column(name = "pro_peso")
	private String peso_produto;
	
	@NotNull(message="{produto.altura.NotEmpty}")
	@Size(min=1, max=10, message = "{produto.altura.Size}")
	@Column(name = "pro_altura")
	private String altura_produto;
	
	@NotNull(message="{produto.largura.NotEmpty}")
	@Size(min=1, max=10, message = "{produto.largura.Size}")
	@Column(name = "pro_largura")
	private String largura_produto;
	
	@NotNull(message="{produto.comprimento.NotEmpty}")
	@Size(min=1, max=10, message = "{produto.comprimento.Size}")
	@Column(name = "pro_comprimento")
	private String comprimento_produto;
	
	@NotNull(message="{produto.garantia.NotEmpty}")
	@Size(min=1, max=100, message = "{produto.garantia.Size}")
	@Column(name = "pro_garantia")
	private String garantia_produto;
	
	/*
	 |--------------------------------------
	 |			Relacionamentos				
	 |--------------------------------------
	 */

	// ENVIA , orphanRemoval=true
	@OneToMany(cascade = CascadeType.ALL, mappedBy="produto", fetch=FetchType.EAGER)
	private Set<Imagem> imagem;
	
	// ENVIA						cascade = CascadeType.MERGE, 
	@ManyToMany(mappedBy = "produto", cascade=CascadeType.ALL)
	private Set<Pedido> pedido;
	

	// RECEBE
	/*@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinTable(name = "produto_has_fornecedor", catalog = "public",
				joinColumns = { @JoinColumn(name = "produto_id_produto") },
				inverseJoinColumns = { @JoinColumn(name = "fornecedor_id_fornecedor") })
	private Set<Fornecedor> fornecedor;*/
	
	// MUITOS Fornecedores tem UM Produto
	@ManyToOne
	@JoinColumn(name = "fornecedor_id_fornecedor")
	private Fornecedor fornecedor;
	
	// MUITOS Banners tem UM Produto
	@ManyToOne
	@JoinColumn(name = "categoria_id_categoria")
	private Categoria categoria;
	
	
	// UM Produto pode estar em MUITOS Banners
	@OneToMany(cascade = CascadeType.REMOVE, mappedBy="produto", fetch=FetchType.EAGER)
	private Set<Banner> banner;
	
	//, orphanRemoval=true
	@OneToMany(cascade = CascadeType.ALL, mappedBy="produto", fetch=FetchType.EAGER)
	private Set<Avaliacao> avaliacao;
	
	
	/*
	|---------------------------------------
	|		Getters And Setters(GGAS)				
	|---------------------------------------
	*/

	public Long getId_produto() {
		return id_produto;
	}

	public void setId_produto(Long id_produto) {
		this.id_produto = id_produto;
	}

	public String getNome_produto() {
		return nome_produto;
	}

	public void setNome_produto(String nome_produto) {
		this.nome_produto = nome_produto;
	}

	public float getPreco_produto() {
		return preco_produto;
	}

	public void setPreco_produto(float preco_produto) {
		this.preco_produto = preco_produto;
	}

	public String getDescricao_produto() {
		return descricao_produto;
	}

	public void setDescricao_produto(String descricao_produto) {
		this.descricao_produto = descricao_produto;
	}

	public boolean isPublicado_produto() {
		return publicado_produto;
	}

	public void setPublicado_produto(boolean publicado_produto) {
		this.publicado_produto = publicado_produto;
	}

	public boolean isDestaque_produto() {
		return destaque_produto;
	}

	public void setDestaque_produto(boolean destaque_produto) {
		this.destaque_produto = destaque_produto;
	}

	public long getDesconto_produto() {
		return desconto_produto;
	}

	public void setDesconto_produto(long desconto_produto) {
		this.desconto_produto = desconto_produto;
	}

	public boolean isPromocao_produto() {
		return promocao_produto;
	}

	public void setPromocao_produto(boolean promocao_produto) {
		this.promocao_produto = promocao_produto;
	}

	public String getPeso_produto() {
		return peso_produto;
	}

	public void setPeso_produto(String peso_produto) {
		this.peso_produto = peso_produto;
	}

	public String getAltura_produto() {
		return altura_produto;
	}

	public void setAltura_produto(String altura_produto) {
		this.altura_produto = altura_produto;
	}

	public String getLargura_produto() {
		return largura_produto;
	}

	public void setLargura_produto(String largura_produto) {
		this.largura_produto = largura_produto;
	}

	public String getComprimento_produto() {
		return comprimento_produto;
	}

	public void setComprimento_produto(String comprimento_produto) {
		this.comprimento_produto = comprimento_produto;
	}

	public String getGarantia_produto() {
		return garantia_produto;
	}

	public void setGarantia_produto(String garantia_produto) {
		this.garantia_produto = garantia_produto;
	}

	public void setId_produto(long id_produto) {
		this.id_produto = id_produto;
	}

	public Set<Banner> getBanner() {
		return banner;
	}

	public void setBanner(Set<Banner> banner) {
		this.banner = banner;
	}

	public Set<Pedido> getPedido() {
		return pedido;
	}

	public void setPedido(Set<Pedido> pedido) {
		this.pedido = pedido;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public Set<Avaliacao> getAvaliacao() {
		return avaliacao;
	}

	public void setAvaliacao(Set<Avaliacao> avaliacao) {
		this.avaliacao = avaliacao;
	}

	public Fornecedor getFornecedor() {
		return fornecedor;
	}

	public void setFornecedor(Fornecedor fornecedor) {
		this.fornecedor = fornecedor;
	}

	public Set<Imagem> getImagem() {
		return imagem;
	}

	public void setImagem(Set<Imagem> imagem) {
		this.imagem = imagem;
	}
	
}
