package br.com.monster.portal.modelDao;

import java.util.List;

import br.com.monster.portal.model.Acessos;

public interface AcessosDao {
	List<Acessos> Read();
	  void create(Acessos Acessos);
	  void update(Acessos t);
	  void delete(Acessos t);
}
