package br.com.monster.portal.modelDao;

import java.util.List;

import br.com.monster.portal.model.Imagem;

public interface ImagemDao {

	  List<Imagem> Read();
	  void create(Imagem Imagem);
	  void update(Imagem t);
	  void delete(Imagem t);
}
