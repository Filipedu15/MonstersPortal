package br.com.monster.portal.modelDao;

import java.util.Date;
import java.util.List;

import br.com.monster.portal.model.Cliente;
import br.com.monster.portal.model.Pedido;

public interface PedidoDao {
	List<Pedido> Read();
	  void create(Pedido pedido);
	  void update(Pedido t);
	  void delete(Pedido t);
	  List<Pedido> Find(Date data_pedido, Pedido pedido);
	Object Find_pedido_boleto(String numb_ped, Pedido pedido);
	List<Pedido> Find_ped_cli(Cliente clienteInfo, Pedido pedido);
	List<Pedido> Pedidos_por_semana();
}
