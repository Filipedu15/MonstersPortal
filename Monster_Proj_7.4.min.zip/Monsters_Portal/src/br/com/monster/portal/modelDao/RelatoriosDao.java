package br.com.monster.portal.modelDao;

import java.util.List;

import br.com.monster.portal.model.Relatorios;

public interface RelatoriosDao {

	  List<Relatorios> Read();
	  void create(Relatorios relatorios);
	  void update(Relatorios t);
	  void delete(Relatorios t);
}
