package br.com.monster.portal.modelDao;

import java.util.List;

import br.com.monster.portal.model.Funcionario;

public interface FuncionarioDao {
	List<Funcionario> Read();
	  void create(Funcionario funcionario);
	  void update(Funcionario t);
	  void delete(Funcionario t);
	boolean FuncionarioExiste(Funcionario funcionario);
}
