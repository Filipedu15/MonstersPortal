package br.com.monster.portal.modelDao;

import java.util.List;

import br.com.monster.portal.model.Imagem;
import br.com.monster.portal.model.Produto;

public interface ProdutoDao {
	
	List<Produto> Read();
	Object Read_publico();
	Object Read_destacado();
	  void create(Produto produto, Imagem imagem);
	  void update(Produto t);
	  void delete(Produto t);
	  
	List<Produto> Find(String nome_prod, Produto produto);
	List<Produto> Find_publico(String nome_produto, Produto produto);
	Object Find_Many_publico(String nome_prod, Produto produto);
}
