package br.com.monster.portal.modelDao;

import java.util.List;

import br.com.monster.portal.model.Avaliacao;
import br.com.monster.portal.model.Produto;

public interface AvaliacaoDao {

	  List<Avaliacao> Read(String nome_produto, Produto produto, Avaliacao avaliacao);
	  void create(Avaliacao avaliacao);
	  void update(Avaliacao t);
	  void delete(Avaliacao t);
}
