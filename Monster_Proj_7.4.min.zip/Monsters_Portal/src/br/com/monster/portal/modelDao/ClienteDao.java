package br.com.monster.portal.modelDao;

import java.util.List;

import br.com.monster.portal.model.Cliente;

public interface ClienteDao {
	
	List<Cliente> Read();
	
	  void create(Cliente cliente);
	  void update(Cliente t);
	  void delete(Cliente t);
	  List<Cliente> Find(String nome_cliente, Cliente cliente);
	boolean UsuarioExiste(Cliente cliente);
	List<Cliente> SeUsuarioExiste(Cliente cliente);
	

	List<Cliente> Qtd_clientes();
	List<Cliente> Qtd_Clientes_Homens();
	List<Cliente> Qtd_Clientes_Mulheres();
}
