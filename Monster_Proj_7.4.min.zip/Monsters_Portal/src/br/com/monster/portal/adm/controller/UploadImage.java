package br.com.monster.portal.adm.controller;

public class UploadImage {
	
}